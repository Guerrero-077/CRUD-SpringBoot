package com.sena.TaskManagement.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity(name = "tasks")
public class Tasks {

    // ===================
    // = Attributes =
    // ===================

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "title")
    private String title;

    @Column(name = "description")
    private String description;

    @Column(name = "creation_date")
    private LocalDateTime creation_date;

    @Column(name = "expiration_date")
    private LocalDateTime expiration_date;

    @Column(name = "active")
    private boolean active;

    // ===================
    // = Relaciones =
    // ===================

    @OneToMany(mappedBy = "tasksForSubTasks")
    private List<SubTasks> subTasks = new ArrayList<>();

    @OneToMany(mappedBy = "taskForHistory")
    private List<History> history = new ArrayList<>();

    @OneToMany(mappedBy = "tasks")
    private List<TasksCategories> tasksCategories = new ArrayList<>();

    @OneToMany(mappedBy = "tasksForCategories")
    private List<TasksTags> tasksTags = new ArrayList<>();

    @OneToMany(mappedBy = "tasksForPriorities")
    private List<TasksPriorities> tasksPriorities = new ArrayList<>();

    @OneToMany(mappedBy = "tasksForReminders")
    private List<Reminders> reminders = new ArrayList<>();

    // ===========================
    // Constructors =
    // ===========================

    public Tasks() {
    }
    
        public Tasks(int id, String title, String description, LocalDateTime creation_date, LocalDateTime expiration_date,
                boolean active, List<SubTasks> subTasks, List<History> history, List<TasksCategories> tasksCategories,
                List<TasksTags> tasksTags, List<TasksPriorities> tasksPriorities, List<Reminders> reminders) {
            this.id = id;
            this.title = title;
            this.description = description;
            this.creation_date = creation_date;
            this.expiration_date = expiration_date;
            this.active = active;
            this.subTasks = subTasks;
            this.history = history;
            this.tasksCategories = tasksCategories;
            this.tasksTags = tasksTags;
            this.tasksPriorities = tasksPriorities;
            this.reminders = reminders;
        }


    // ==========================
    // = Getters and Setters =
    // ==========================


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreation_date() {
        return creation_date;
    }

    public void setCreation_date(LocalDateTime creation_date) {
        this.creation_date = creation_date;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public List<SubTasks> getSubTasks() {
        return subTasks;
    }

    public void setSubTasks(List<SubTasks> subTasks) {
        this.subTasks = subTasks;
    }

    public List<History> getHistory() {
        return history;
    }

    public void setHistory(List<History> history) {
        this.history = history;
    }

    public List<TasksCategories> getTasksCategories() {
        return tasksCategories;
    }

    public void setTasksCategories(List<TasksCategories> tasksCategories) {
        this.tasksCategories = tasksCategories;
    }

    public List<TasksTags> getTasksTags() {
        return tasksTags;
    }

    public void setTasksTags(List<TasksTags> tasksTags) {
        this.tasksTags = tasksTags;
    }

    public List<TasksPriorities> getTasksPriorities() {
        return tasksPriorities;
    }

    public void setTasksPriorities(List<TasksPriorities> tasksPriorities) {
        this.tasksPriorities = tasksPriorities;
    }

    public List<Reminders> getReminders() {
        return reminders;
    }

    public void setReminders(List<Reminders> reminders) {
        this.reminders = reminders;
    }

    public LocalDateTime getExpiration_date() {
        return expiration_date;
    }

    public void setExpiration_date(LocalDateTime expiration_date) {
        this.expiration_date = expiration_date;
    }
    

}
