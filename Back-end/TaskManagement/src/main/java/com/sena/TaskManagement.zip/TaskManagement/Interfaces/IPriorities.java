package com.sena.TaskManagement.Interfaces;

public interface IPriorities {

}
