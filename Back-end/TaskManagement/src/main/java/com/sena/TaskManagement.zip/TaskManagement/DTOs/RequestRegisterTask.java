package com.sena.TaskManagement.DTOs;

import java.time.LocalDateTime;
import java.util.List;

public class RequestRegisterTask {

    /*
     * Agregar al DTO solo los elementos a exponer según
     * la petición o respuesta
     */

    // ===================
    // = Attributes =
    // ===================

    private int id;
    private String title;
    private String description;
    private LocalDateTime expiration_date;
    private boolean active;
    private List<Integer> categoryIds;
    private List<Integer> tagIds;
    private Integer priorityId;
    // ===========================
    // Constructors =
    // ===========================

    public RequestRegisterTask() {
    }
    
        public RequestRegisterTask(int id, String title, String description, LocalDateTime expiration_date, boolean active,
                List<Integer> categoryIds, List<Integer> tagIds, Integer priorityId) {
            this.id = id;
            this.title = title;
            this.description = description;
            this.expiration_date = expiration_date;
            this.active = active;
            this.categoryIds = categoryIds;
            this.tagIds = tagIds;
            this.priorityId = priorityId;
        }



    // ==========================
    // = Getters and Setters =
    // ==========================



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getExpiration_date() {
        return expiration_date;
    }

    public void setExpiration_date(LocalDateTime expiration_date) {
        this.expiration_date = expiration_date;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public List<Integer> getCategoryIds() {
        return categoryIds;
    }

    public void setCategoryIds(List<Integer> categoryIds) {
        this.categoryIds = categoryIds;
    }

    public List<Integer> getTagIds() {
        return tagIds;
    }

    public void setTagIds(List<Integer> tagIds) {
        this.tagIds = tagIds;
    }

    public Integer getPriorityId() {
        return priorityId;
    }

    public void setPriorityId(Integer priorityId) {
        this.priorityId = priorityId;
    }



}
