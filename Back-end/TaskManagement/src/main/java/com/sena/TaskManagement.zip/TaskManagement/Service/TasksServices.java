package com.sena.TaskManagement.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.TaskManagement.DTOs.RequestRegisterTask;
import com.sena.TaskManagement.Interfaces.ITasks;
import com.sena.TaskManagement.model.Tasks;

@Service
public class TasksServices {
    /*
     * @Autowired = Incluye la conexión de la interface
     */
    @Autowired
    private ITasks tasksData;

    public List<Tasks> findAllTareas() {
        return tasksData.findAll();
    }
    
    public Optional<Tasks> findByIdTareas(int id) {
        return tasksData.findById(id);
    }

    public void save(RequestRegisterTask task) {
        tasksData.save(convertRegisterToTask(task));
    }

    public Tasks convertRegisterToTask(RequestRegisterTask task) {
        return new Tasks(
                0, // ID automático
                task.getTitle(),
                task.getDescription(),
                LocalDateTime.now(), // Creación automática
                task.getExpiration_date(),
                true, // Activo por defecto
                new ArrayList<>(), // subTasks
                new ArrayList<>(), // history
                new ArrayList<>(), // tasksCategories
                new ArrayList<>(), // tasksTags
                new ArrayList<>(), // tasksPriorities
                new ArrayList<>() // reminders
        );
    }   

    public Tasks createTask(RequestRegisterTask request) {
        Tasks task = new Tasks();
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setCreation_date(LocalDateTime.now());
        task.setExpiration_date(request.getExpiration_date()); // <-- Agregado
        task.setActive(true);

        return tasksData.save(task);
    }

    public void update(int id, Tasks taskUpdate) {
        var task = findByIdTareas(id);
        if (task.isPresent()) {
            task.get().setTitle(taskUpdate.getTitle());
            task.get().setDescription(taskUpdate.getDescription());
            tasksData.save(task.get());

        }
    }

    public void delete(int id) {
        var task = findByIdTareas(id);
        if (task.isPresent()) {// trae un boolean si existe o no
            tasksData.delete(task.get());
        }
    }


    public List<Tasks> filterForTitle(String title) {
        return tasksData.findByTitleContainingIgnoreCase(title);
    }
}
