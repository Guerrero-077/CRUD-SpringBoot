package com.sena.TaskManagement.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity(name = "tasksPriorities")
public class TasksPriorities {

    // ===================
    // = Attributes =
    // ===================

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    // ===================
    // = Relaciones =
    // ===================
    @ManyToOne
    @JoinColumn(name = "task_id")
    private Tasks tasksForPriorities;

    @ManyToOne
    @JoinColumn(name = "priority_id")
    private Priorities priorityForTasks;

    
    // ===========================
    // Constructors =
    // ===========================
    
    public TasksPriorities() {
    }


    public TasksPriorities(int id, Tasks tasksForPriorities, Priorities priorityForTasks) {
        this.id = id;
        this.tasksForPriorities = tasksForPriorities;
        this.priorityForTasks = priorityForTasks;
    }


    // ==========================
    // = Getters and Setters =
    // ==========================

    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }


    public Tasks getTasksForPriorities() {
        return tasksForPriorities;
    }


    public void setTasksForPriorities(Tasks tasksForPriorities) {
        this.tasksForPriorities = tasksForPriorities;
    }


    public Priorities getPriorityForTasks() {
        return priorityForTasks;
    }


    public void setPriorityForTasks(Priorities priorityForTasks) {
        this.priorityForTasks = priorityForTasks;
    }


    
}
