package com.sena.TaskManagement.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity(name = "priorities")
public class Priorities {

    // ===================
    // = Attributes =
    // ===================

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    // ===================
    // = Relaciones =
    // ===================

    @OneToMany(mappedBy = "priorityForTasks")
    private List<TasksPriorities> tasksPriorities = new ArrayList<>();

    // ===========================
    // Constructors =
    // ===========================

    public Priorities() {
    }

    public Priorities(int id, String name, List<TasksPriorities> tasksPriorities) {
        this.id = id;
        this.name = name;
        this.tasksPriorities = tasksPriorities;
    }

    // ==========================
    // = Getters and Setters =
    // ==========================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<TasksPriorities> getTasksPriorities() {
        return tasksPriorities;
    }

    public void setTasksPriorities(List<TasksPriorities> tasksPriorities) {
        this.tasksPriorities = tasksPriorities;
    }

}
