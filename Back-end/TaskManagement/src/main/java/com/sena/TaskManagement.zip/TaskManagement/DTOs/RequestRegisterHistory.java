// package com.sena.TaskManagement.DTOs;

// import java.time.LocalDateTime;

// import jakarta.persistence.Entity;

// @Entity(name = "history")
// public class RequestRegisterHistory {

//     // ===================
//     // = Attributes =
//     // ===================

//     private int id;
//     private String history_action;
//     private LocalDateTime history_date;

//     // ===========================
//     // Constructors =
//     // ===========================

//     public RequestRegisterHistory() {
//     }

//     public RequestRegisterHistory(int id, String history_action, LocalDateTime history_date) {
//         this.id = id;
//         this.history_action = history_action;
//         this.history_date = history_date;
//     }

//     // ==========================
//     // = Getters and Setters =
//     // ==========================

//     public int getId() {
//         return id;
//     }

//     public void setId(int id) {
//         this.id = id;
//     }

//     public String getHistory_action() {
//         return history_action;
//     }

//     public void setHistory_action(String history_action) {
//         this.history_action = history_action;
//     }

//     public LocalDateTime getHistory_date() {
//         return history_date;
//     }

//     public void setHistory_date(LocalDateTime history_date) {
//         this.history_date = history_date;
//     }
// }
