package com.sena.TaskManagement.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity(name = "tasksTags")
public class TasksTags {

    // ===================
    // = Attributes =
    // ===================

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    // ===================
    // = Relaciones =
    // ===================

    @ManyToOne
    @JoinColumn(name = "task_id")
    private Tasks tasksForCategories;

    @ManyToOne
    @JoinColumn(name = "tag_id")
    private Tags tagsForCategories;

    
    // ===========================
    // Constructors =
    // ===========================
    
    public TasksTags() {
    }

    public TasksTags(int id, Tasks tasksForCategories, Tags tagsForCategories) {
        this.id = id;
        this.tasksForCategories = tasksForCategories;
        this.tagsForCategories = tagsForCategories;
    }

    // ==========================
    // = Getters and Setters =
    // ==========================

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Tasks getTasksForCategories() {
        return tasksForCategories;
    }

    public void setTasksForCategories(Tasks tasksForCategories) {
        this.tasksForCategories = tasksForCategories;
    }

    public Tags getTagsForCategories() {
        return tagsForCategories;
    }

    public void setTagsForCategories(Tags tagsForCategories) {
        this.tagsForCategories = tagsForCategories;
    }
    


}
